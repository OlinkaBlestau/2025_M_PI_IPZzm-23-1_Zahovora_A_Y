import numpy as np
from flask_cors import CORS

def normalize_matrix(matrix):
    column_sums = np.sum(matrix, axis=0)
    return matrix / column_sums

def calculate_priority_vector(normalized_matrix):
    return np.mean(normalized_matrix, axis=1)

def ahp(matrix):
    matrix = np.array(matrix, dtype=float)
    norm_matrix = normalize_matrix(matrix)
    priority_vector = calculate_priority_vector(norm_matrix)
    return priority_vector.tolist()

if __name__ == "__main__":
    # Матриця попарних порівнянь між 3 критеріями
    # Наприклад: Зарплата, Інтерес, Попит
    pairwise_matrix = [
        [1,     3,     0.5],
        [1/3,   1,     0.2],
        [2,     5,     1]
    ]

    weights = ahp(pairwise_matrix)
    print("Ваги критеріїв:", weights)
