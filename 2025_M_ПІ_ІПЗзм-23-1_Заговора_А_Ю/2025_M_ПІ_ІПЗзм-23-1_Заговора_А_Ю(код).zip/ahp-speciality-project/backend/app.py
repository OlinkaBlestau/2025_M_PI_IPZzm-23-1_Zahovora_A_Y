from flask import Flask, request, jsonify
from flask_cors import CORS
from ahp import ahp
from flask import send_file
from anp import ANPModel
from report_service import build_pdf_report
from anp_alternatives import register_anp_alternatives_routes
import numpy as np  # ← додай, якщо ще не додала


app = Flask(__name__)
register_anp_alternatives_routes(app)
CORS(app)

RI_TABLE = {
    1: 0.00,
    2: 0.00,
    3: 0.58,
    4: 0.90,
    5: 1.12,
    6: 1.24,
    7: 1.32,
    8: 1.41,
    9: 1.45,
    10: 1.49
}

@app.route("/generate-report", methods=["POST"])
def generate_report():
    pdf_buffer = build_pdf_report()
    pdf_buffer.seek(0)  # обов'язково, щоб PDF починався з початку
    return send_file(
        pdf_buffer,
        as_attachment=True,
        download_name="ahp_anp_report.pdf",
        mimetype="application/pdf"
    )

@app.route('/calculate', methods=['POST'])
def calculate_weights():
    data = request.get_json()
    matrix = data.get('matrix')

    if not matrix:
        return jsonify({'error': 'Матриця не надана'}), 400

    try:
        matrix_np = np.array(matrix, dtype=float)
        n = matrix_np.shape[0]

        # Отримуємо ваги з ahp()
        weights = np.array(ahp(matrix))

        # Знаходимо λ_max
        λ_max = np.sum(np.dot(matrix_np, weights) / weights) / n
        ci = (λ_max - n) / (n - 1) if n > 1 else 0
        ri = RI_TABLE.get(n, 1.49)
        cr = ci / ri if ri != 0 else 0

        return jsonify({
            'weights': weights.tolist(),
            'ci': round(ci, 4),
            'cr': round(cr, 4)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 50

@app.route('/final-calculate', methods=['POST'])
def final_calculation():
    data = request.get_json()
    criteria_weights = data.get('criteria_weights')
    alternative_matrices = data.get('alternative_matrices')

    try:
        alternative_weights = {}
        consistency_data = {}

        for crit, matrix in alternative_matrices.items():
            matrix_np = np.array(matrix, dtype=float)
            n = matrix_np.shape[0]

            # Розрахунок ваг
            norm_matrix = matrix_np / np.sum(matrix_np, axis=0)
            weights = np.mean(norm_matrix, axis=1)

            # λ_max, CI, CR
            λ_max = np.sum(np.dot(matrix_np, weights) / weights) / n
            ci = (λ_max - n) / (n - 1) if n > 1 else 0
            ri = RI_TABLE.get(n, 1.49)
            cr = ci / ri if ri != 0 else 0

            alternative_weights[crit] = weights.tolist()
            consistency_data[crit] = {
                'ci': round(ci, 4),
                'cr': round(cr, 4)
            }

        # Розрахунок фінальних ваг
        final_scores = np.zeros(len(next(iter(alternative_weights.values()))))
        for i, crit in enumerate(criteria_weights):
            crit_weight = criteria_weights[i]
            alt_weights = alternative_weights[list(alternative_weights.keys())[i]]
            final_scores += crit_weight * np.array(alt_weights)

        return jsonify({
            'final_scores': final_scores.tolist(),
            'consistency': consistency_data,
            'alternative_weights': alternative_weights
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@app.route('/api/anp', methods=['POST'])
def anp():
    data = request.json

    criteria = data['criteria']  # список критеріїв
    dependencies = data['dependencies']  # { критерій: [список залежних] }
    comparisons = np.array(data['comparisons'])  # матриця парних порівнянь
    influence = {}
    for key, value in data['influence'].items():
        crit_i, crit_j = key.split(",")
        influence[(crit_i.strip(), crit_j.strip())] = value
    # Створюємо модель ANP
    model = ANPModel(criteria, dependencies, comparisons, influence)

    supermatrix = model.build_supermatrix()
    normalized_supermatrix = model.normalize_supermatrix(supermatrix)
    priority_vector = model.calculate_priority_vector(normalized_supermatrix)

    result = {crit: round(float(weight), 4) for crit, weight in zip(criteria, priority_vector)}

    return jsonify({
        "supermatrix": supermatrix.tolist(),
        "priority_vector": result
    })





# ← має бути останнім
if __name__ == '__main__':
    app.run(debug=True)
