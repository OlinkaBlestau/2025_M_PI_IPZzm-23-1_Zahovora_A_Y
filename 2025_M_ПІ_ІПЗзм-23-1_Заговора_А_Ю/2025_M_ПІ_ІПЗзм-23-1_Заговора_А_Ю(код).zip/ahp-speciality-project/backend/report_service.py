from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.graphics.shapes import Drawing
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.textlabels import Label
from reportlab.lib import colors
import os
import random
import io
import numpy as np
from ahp import ahp
from anp import ANPModel

pdfmetrics.registerFont(TTFont('DejaVu', os.path.join('DejaVuSans.ttf')))

def build_pdf_report():
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # 1. Задані критерії та альтернативи
    criteria = ["Зарплата", "Інтерес", "Попит", "Карʼєра"]
    alternatives = ["Frontend", "Backend", "QA Engineer", "Data Analyst", "DevOps"]

    # 2. Матриця критеріїв (4x4)
    n = len(criteria)
    matrix = np.ones((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            val = random.choice([1, 3, 5, 7])
            matrix[i][j] = val
            matrix[j][i] = round(1 / val, 2)

    # 3. AHP: вектор пріоритетів
    ahp_weights = ahp(matrix)

    # 4. ANP: модель
    dependencies = {
        "Зарплата": ["Інтерес", "Попит"],
        "Інтерес": ["Попит"],
        "Попит": ["Карʼєра"],
        "Карʼєра": ["Зарплата"]
    }
    influence = {}
    for source, targets in dependencies.items():
        for target in targets:
            influence[(source, target)] = random.choice([1, 3, 5, 7])

    anp_model = ANPModel(criteria, dependencies, matrix, influence)
    supermatrix = anp_model.build_supermatrix()
    norm_super = anp_model.normalize_supermatrix(supermatrix)
    anp_weights = anp_model.calculate_priority_vector(norm_super)

    # 5. Матриця ваг альтернатив (4x5)
    alt_matrix = np.random.dirichlet(np.ones(len(alternatives)), size=len(criteria))

    # 6. Фінальні результати
    ahp_result = ahp_weights @ alt_matrix
    anp_result = anp_weights @ alt_matrix

    best_ahp = alternatives[np.argmax(ahp_result)]
    best_anp = alternatives[np.argmax(anp_result)]


    # Залежності
    dependencies = {
        "Зарплата": ["Інтерес", "Попит"],
        "Інтерес": ["Попит"],
        "Попит": ["Карʼєра"],
        "Карʼєра": ["Зарплата"]
    }

    # Впливи
    influence = {}
    for source, targets in dependencies.items():
        for target in targets:
            influence[(source, target)] = random.choice([1, 3, 5, 7])

    # ANP модель
    anp_model = ANPModel(criteria, dependencies, matrix, influence)
    supermatrix = anp_model.build_supermatrix()
    norm_super = anp_model.normalize_supermatrix(supermatrix)
    anp_weights = anp_model.calculate_priority_vector(norm_super)

# Випадкові ваги альтернатив для кожного критерію (матриця 4x5)
    alt_matrix = np.random.dirichlet(np.ones(len(alternatives)), size=len(criteria))  # (4 x 5)

# Результати AHP і ANP
    ahp_result = ahp_weights @ alt_matrix
    anp_result = anp_weights @ alt_matrix

    best_ahp = alternatives[np.argmax(ahp_result)]
    best_anp = alternatives[np.argmax(anp_result)]



    # PDF
    c.setFont("DejaVu", 14)
    c.drawString(50, height - 50, "Порівняння методів AHP та ANP")

    y = height - 80
    c.setFont("DejaVu", 11)
    c.drawString(50, y, "Критерії:")
    for crit in criteria:
        y -= 15
        c.drawString(70, y, f"- {crit}")

    # Матриця
    y -= 25
    c.setFont("DejaVu", 11)
    c.drawString(50, y, "Матриця попарного порівняння критеріїв:")
    y -= 14
    c.setFont("DejaVu", 9)
    header = "       " + "  ".join([f"{c:>8}" for c in criteria])
    c.drawString(50, y, header)
    for i, row in enumerate(matrix):
        y -= 12
        row_str = f"{criteria[i]:<8} " + " ".join([f"{val:>8.2f}" for val in row])
        c.drawString(50, y, row_str)

    # Вектори пріоритетів
    y -= 25
    c.setFont("DejaVu", 11)
    c.drawString(50, y, "Вектори пріоритетів критеріїв:")
    y -= 14
    for i, crit in enumerate(criteria):
        c.drawString(60, y, f"{crit}:  AHP = {ahp_weights[i]:.3f}   ANP = {anp_weights[i]:.3f}")
        y -= 14

    # Впливи
    y -= 10
    c.setFont("DejaVu", 11)
    c.drawString(50, y, "Впливи між критеріями:")
    c.setFont("DejaVu", 10)
    for (src, tgt), val in influence.items():
        y -= 14
        c.drawString(60, y, f"{src} → {tgt} = {val}")

    # Альтернативи
    y -= 25
    c.setFont("DejaVu", 11)
    c.drawString(50, y, "Альтернативи та ваги:")
    c.setFont("DejaVu", 10)
    for i, alt in enumerate(alternatives):
        y -= 14
        c.drawString(60, y, f"{alt:12}  AHP = {ahp_result[i]:.3f}    ANP = {anp_result[i]:.3f}")


    # Рекомендації
    y -= 30
    c.setFont("DejaVu", 11)
    c.drawString(50, y, f"Рекомендована альтернатива (AHP): {best_ahp}")
    y -= 18
    c.drawString(50, y, f"Рекомендована альтернатива (ANP): {best_anp}")

# Графік AHP vs ANP для альтернатив
    drawing = Drawing(400, 200)
    chart = VerticalBarChart()
    chart.x = 50
    chart.y = 30
    chart.height = 120
    chart.width = 300

    # Дані: [[AHP_values], [ANP_values]]
    chart.data = [ahp_result.flatten().tolist(), anp_result.flatten().tolist()]
    chart.strokeColor = colors.black

    chart.categoryAxis.categoryNames = alternatives
    chart.categoryAxis.labels.boxAnchor = 'ne'
    chart.valueAxis.valueMin = 0
    chart.valueAxis.valueMax = 1.0
    chart.valueAxis.valueStep = 0.1

    chart.barWidth = 10
    chart.groupSpacing = 15
    chart.barSpacing = 5

    # Додаємо легенду
    c.setFont("DejaVu", 10)
    c.drawString(200, 90, "AHP (синій) vs ANP (червоний)")


    # Кольори колонок
    chart.bars[0].fillColor = colors.lightblue
    chart.bars[1].fillColor = colors.salmon

    drawing.add(chart)
    drawing.drawOn(c, 80, 100)

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer
