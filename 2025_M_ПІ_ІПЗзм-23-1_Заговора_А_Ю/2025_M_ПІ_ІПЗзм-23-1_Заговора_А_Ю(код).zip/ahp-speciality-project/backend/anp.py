import numpy as np

class ANPModel:
    def __init__(self, criteria, dependencies, comparisons, influence):
        """
        :param criteria: список критеріїв
        :param dependencies: словник {критерій: [список критеріїв, на які він впливає]}
        :param comparisons: матриця парних порівнянь критеріїв (NxN)
        :param influence: словник {(критерій1, критерій2): значення впливу}
        """
        self.criteria = criteria
        self.dependencies = dependencies
        self.comparisons = comparisons
        self.influence = influence

    def _calculate_weights(self, comparison_matrix):
        """
        Власне розрахунок ваг критеріїв з AHP — через власні вектори.
        """
        eigvals, eigvecs = np.linalg.eig(comparison_matrix)
        max_index = np.argmax(np.real(eigvals))
        weights = np.real(eigvecs[:, max_index])
        weights = weights / np.sum(weights)
        return weights

    def build_supermatrix(self):
        """
        Побудова початкової суперматриці з урахуванням залежностей та впливу.
        """
        n = len(self.criteria)
        weights = self._calculate_weights(np.array(self.comparisons))
        supermatrix = np.zeros((n, n))

        for i, source in enumerate(self.criteria):
            for j, target in enumerate(self.criteria):
                if target in self.dependencies.get(source, []):
                    infl = self.influence.get((source, target), 0)
                    supermatrix[j, i] = infl * weights[j]  # 🔥 локальна вага + вплив
                elif i == j:
                    supermatrix[j, i] = weights[i]  # самовплив

        return supermatrix

    def normalize_supermatrix(self, supermatrix):
        """
        Нормалізація суперматриці по стовпцях (W-column stochastic).
        """
        column_sums = supermatrix.sum(axis=0)
        column_sums = np.where(column_sums == 0, 1, column_sums)  # уникнення ділення на 0
        return supermatrix / column_sums

    def calculate_priority_vector(self, normalized_supermatrix, power=50):
        """
        Обчислення лімітної матриці W^k та отримання пріоритетного вектора.
        """
        limit_matrix = np.linalg.matrix_power(normalized_supermatrix, power)
        vector = np.mean(limit_matrix, axis=1)
        vector = np.where(vector == 0, 1e-6, vector)
        return vector / vector.sum()

    def run(self):
        """
        Повний розрахунок ANP: суперматриця → нормалізація → пріоритети
        """
        supermatrix = self.build_supermatrix()
        normalized = self.normalize_supermatrix(supermatrix)
        priority_vector = self.calculate_priority_vector(normalized)
        return {
            "supermatrix": normalized.tolist(),
            "priority_vector": dict(zip(self.criteria, priority_vector.round(4)))
        }
