from flask import request, jsonify
import numpy as np

def normalize_matrix(matrix):
    matrix = np.array(matrix, dtype=float)
    column_sums = matrix.sum(axis=0)
    return matrix / column_sums

def build_supermatrix(criteria, matrices):
    n_criteria = len(criteria)
    n_alts = len(next(iter(matrices.values())))
    supermatrix = np.zeros((n_criteria * n_alts, n_criteria * n_alts))

    for i, crit in enumerate(criteria):
        local_matrix = normalize_matrix(matrices[crit])
        for j in range(n_criteria):
            if i == j:
                supermatrix[i*n_alts:(i+1)*n_alts, j*n_alts:(j+1)*n_alts] = local_matrix
            else:
                supermatrix[i*n_alts:(i+1)*n_alts, j*n_alts:(j+1)*n_alts] = np.zeros_like(local_matrix)

    return supermatrix

def limit_matrix(matrix, power=50):
    return np.linalg.matrix_power(matrix, power)

def register_anp_alternatives_routes(app):
    @app.route('/anp_alternatives/final', methods=['POST'])
    def final_anp_alternatives():
        try:
            data = request.get_json()
            criteria = data.get('criteria')
            matrices = data.get('matrices')

            if not criteria or not matrices:
                return jsonify({'error': 'Missing criteria or matrices'}), 400

            # Convert all matrices to numpy arrays
            matrices_np = {k: np.array(v, dtype=float) for k, v in matrices.items()}

            # Build and limit the supermatrix
            supermatrix = build_supermatrix(criteria, matrices_np)
            limit_super = limit_matrix(supermatrix)

            n_alts = len(next(iter(matrices.values())))
            n_criteria = len(criteria)

            # Обчислюємо фінальні ваги альтернатив: усереднене значення по кожному альтернативному блоку
            scores = np.zeros(n_alts)
            for i in range(n_criteria):
                block = limit_super[i * n_alts : (i + 1) * n_alts, :]
                scores += block.mean(axis=1)
            scores /= n_criteria

            # Нормалізуємо
            scores /= scores.sum()

            return jsonify({'final_scores': scores.tolist()})
        except Exception as e:
            return jsonify({'error': str(e)}), 500