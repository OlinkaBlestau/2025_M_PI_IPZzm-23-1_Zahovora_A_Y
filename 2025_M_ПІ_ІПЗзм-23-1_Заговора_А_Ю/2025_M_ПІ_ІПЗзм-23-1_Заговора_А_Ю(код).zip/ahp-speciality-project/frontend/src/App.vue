<template>
  <div class="min-h-screen bg-gray-50 py-10">
    <div class="max-w-8xl mx-auto px-4">
      <h1 class="text-2xl font-bold text-center mb-8">
        AHP vs ANP: моделювання ієрархії знань предметної області (вибір IT - спеціальності)
      </h1>
      <button
        @click="downloadReport"
        class="block mx-auto mb-10 px-6 py-2 bg-green-600 text-white rounded hover:bg-indigo-700"
      >
        Генерація порівняльного звіту (випадкові дані)
      </button>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <!-- AHP -->
        <div class="border rounded p-4 shadow">
          <!-- Навігація -->
          <div class="max-w-4xl mx-auto">
          <h1 class="flex justify-center gap-4 mb-8 font-bold">Analytic Hierarchy Process</h1>
            <div class="flex justify-center gap-4 mb-8">
            
              <button
                @click="currentStep = 1"
                class="px-4 py-2 rounded"
                :class="
                  currentStep === 1
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-200 text-gray-800'
                "
              >
                1. Критерії
              </button>
              <button
                :disabled="!step1Completed"
                @click="currentStep = 2"
                class="px-4 py-2 rounded"
                :class="[
                  step1Completed
                    ? 'hover:bg-indigo-500'
                    : 'cursor-not-allowed opacity-50',
                  currentStep === 2
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-200 text-gray-800',
                ]"
              >
                2. Альтернативи
              </button>
            </div>

            <!-- Крок 1 -->
            <div v-if="currentStep === 1">
              <CriteriaComparison
                :initialCriteria="criteriaLabels"
                :initialComparisons="criteriaComparisons"
                @calculated="onCriteriaCalculated"
                @updateCriteriaList="onCriteriaListUpdated"
                @updateComparisons="onComparisonsUpdated"
              />
            </div>

            <!-- Крок 2 -->
            <div v-if="currentStep === 2 && step1Completed">
              <AlternativeComparison
                :criteriaLabels="criteriaLabels"
                :criteriaWeights="criteriaWeights"
                :initialMatrices="altMatrices"
                :alternatives="alternatives"
                @updateMatrices="altMatrices = $event"
                @updateAlternatives="onUpdateAlternatives"
              />
            </div>
          </div>
        </div>

        <!-- ANP -->
        <div class="border rounded p-4 shadow">
        <h1 class="flex justify-center gap-4 mb-8 font-bold">Analytic Network Process</h1>
          <div class="max-w-4xl mx-auto">
            <!-- Вкладки ANP -->
            <div class="flex justify-center gap-4 mb-8">
              <button
                @click="currentAnpStep = 1"
                class="px-4 py-2 rounded"
                :class="
                  currentAnpStep === 1
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-200 text-gray-800'
                "
              >
                1. Критерії
              </button>
              <button
                :disabled="!anpStep1Completed"
                @click="currentAnpStep = 2"
                class="px-4 py-2 rounded"
                :class="[
                  anpStep1Completed
                    ? 'hover:bg-indigo-500'
                    : 'cursor-not-allowed opacity-50',
                  currentAnpStep === 2
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-200 text-gray-800',
                ]"
              >
                2. Альтернативи
              </button>
            </div>

            <!-- Крок 1 -->
            <AnpComparison
              v-if="currentAnpStep === 1"
              :initialCriteria="anpCriteriaList"
              :initialComparisons="anpComparisons"
              :initialDependencies="anpDependencies"
              :initialInfluence="anpInfluence"
              @step1Completed="onAnpStep1Completed"
              @updateCriteria="anpCriteriaList = $event"
              @updateComparisons="anpComparisons = $event"
              @updateDependencies="anpDependencies = $event"
              @updateInfluence="anpInfluence = $event"
            />

            <!-- Крок 2 -->
            <div v-if="currentAnpStep === 2 && anpStep1Completed">
              <AnpAlternatives
                :criteria="anpCriteriaList"
                :alternatives="alternatives"
                :matrices="anpAltMatrices"
                :comparisons="anpComparisonsPerCriterion"
                @updateAlternatives="alternatives = $event"
                @updateMatrices="anpAltMatrices = $event"
                @updateComparisons="anpComparisonsPerCriterion = $event"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import CriteriaComparison from "./components/CriteriaComparison.vue";
import AlternativeComparison from "./components/AlternativeComparison.vue";
import AnpComparison from "./components/AnpComparison.vue";
import AnpAlternatives from "./components/AnpAlternatives.vue";

export default {
  components: {
    CriteriaComparison,
    AlternativeComparison,
    AnpAlternatives,
    AnpComparison,
  },
  data() {
    return {
      currentStep: 1,
      step1Completed: false,
      criteriaLabels: ["Зарплата", "Інтерес", "Попит"],
      criteriaWeights: [],
      anpComparisonsPerCriterion: {},
      criteriaComparisons: [],
      anpAltMatrices: {},
      currentAnpStep: 1,
      anpCriteriaResult: null, // повний результат з AnpComparison
      anpCriteriaList: [], // оновлений список критеріїв
      anpStep1Completed: false,
      anpResult: null, // 👈 ВАЖЛИВО! без цього нічого не працює
      anpAlternativeMatrices: {}, // матриці альтернатив
      anpAlternatives: [
        // дефолтний список
        "Frontend",
        "Backend",
        "QA Engineer",
        "Data Analyst",
        "DevOps",
        "UI/UX Designer",
      ],
      alternatives: [
        "Frontend",
        "Backend",
        "QA Engineer",
        "Data Analyst",
        "DevOps",
        "UI/UX Designer",
      ],
      altMatrices: {},

      anpComparisons: [
        [1, 1, 1],
        [1, 1, 1],
        [1, 1, 1],
      ],
      anpDependencies: {},
      anpInfluence: {},
    };
  },
  methods: {
    onCriteriaCalculated(weights) {
      this.criteriaWeights = weights;
      this.step1Completed = true;
    },
    onCriteriaListUpdated(list) {
      this.criteriaLabels = list;
    },
    onComparisonsUpdated(comp) {
      this.criteriaComparisons = comp;
    },
    onUpdateAlternatives(newList) {
      this.alternatives = newList;
    },
    onAnpStep1Completed(result) {
      this.anpResult = result;
      this.anpStep1Completed = true;
    },
    async downloadReport() {
      const res = await fetch("http://localhost:5000/generate-report", {
        method: "POST",
      });
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "AHP_ANP_report.pdf");
      document.body.appendChild(link);
      link.click();
      link.remove();
    },
  },
};
</script>
