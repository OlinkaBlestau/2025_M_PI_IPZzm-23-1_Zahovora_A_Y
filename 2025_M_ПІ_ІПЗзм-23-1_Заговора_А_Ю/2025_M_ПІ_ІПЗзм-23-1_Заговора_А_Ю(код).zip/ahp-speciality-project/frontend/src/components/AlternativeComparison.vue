<template>
  <div class="p-8 max-w-6xl mx-auto text-gray-800 font-sans">
    <!-- Альтернативи -->
    <div class="mb-6 p-4 bg-white rounded border shadow">
      <h3 class="text-lg font-semibold text-gray-800 mb-2">Альтернативи</h3>

      <div class="flex gap-2 mb-3">
        <input
          v-model="newAlternative"
          placeholder="Нова альтернатива"
          class="border px-3 py-2 rounded w-full"
        />
        <button
          @click="addAlternative"
          class="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Додати
        </button>
      </div>

      <div>
        <span
          v-for="(alt, index) in alternatives"
          :key="index"
          class="inline-flex items-center bg-gray-200 rounded px-3 py-1 mr-2 mb-2 text-sm"
        >
          {{ alt }}
          <button
            @click="removeAlternative(index)"
            class="ml-2 text-red-600 font-bold"
          >
            ×
          </button>
        </span>
      </div>
    </div>

    <!-- Кожен критерій -->
    <div
      v-for="(criterion, critIndex) in criteriaLabels"
      :key="critIndex"
      class="mb-10 p-4 border rounded-xl shadow-sm bg-white"
    >
      <h3 class="text-xl font-semibold mb-4 text-indigo-700">
        Критерій: {{ criterion }}
      </h3>

      <div
        v-for="(pair, pairIndex) in getPairs(alternatives)"
        :key="pairIndex"
        class="mb-3"
      >
        <label class="block text-sm font-medium mb-1">
          Наскільки <strong>{{ pair[0] }}</strong> краща за
          <strong>{{ pair[1] }}</strong> по критерію "{{ criterion }}"?
        </label>
        <select
          v-model="comparisons[criterion][pairIndex]"
          @change="emitUpdate"
          class="w-full border border-gray-300 rounded px-3 py-2"
        >
          <option
            v-for="(label, value) in scale"
            :key="value"
            :value="parseFloat(value)"
          >
            {{ label }}
          </option>
        </select>
      </div>

      <button
        @click="generateMatrix(criterion)"
        class="mt-4 px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
      >
        Побудувати матрицю для "{{ criterion }}"
      </button>

      <div v-if="matrices[criterion]" class="mt-6">
        <h4 class="text-lg font-medium mb-2">Матриця попарного порівняння</h4>
        <div class="overflow-x-auto">
          <table class="table-auto border-collapse w-full text-sm text-center">
            <thead>
              <tr class="bg-gray-100">
                <th class="border px-2 py-1"></th>
                <th
                  v-for="alt in alternatives"
                  :key="alt"
                  class="border px-2 py-1"
                >
                  {{ alt }}
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(row, i) in matrices[criterion]" :key="i">
                <td class="border px-2 py-1 font-medium bg-gray-50">
                  {{ alternatives[i] }}
                </td>
                <td v-for="(val, j) in row" :key="j" class="border px-2 py-1">
                  {{ val.toFixed(3) }}
                </td>
              </tr>
            </tbody>
          </table>

          <!-- Коєфіцієнти узгодженості -->
          <div v-if="consistency[criterion]" class="mt-2 text-sm">
            <p><strong>CI:</strong> {{ consistency[criterion].ci }}</p>
            <p><strong>CR:</strong> {{ consistency[criterion].cr }}</p>
            <p
              v-if="consistency[criterion].cr <= 0.1"
              class="text-green-600 font-semibold"
            >
              Узгодженість прийнятна ✅
            </p>
            <p v-else class="text-red-600 font-semibold">
              Узгодженість слабка ❗ Рекомендується переглянути порівняння.
            </p>
          </div>
        </div>
      </div>
    </div>

    <button
      class="mt-6 px-6 py-3 bg-green-600 text-white rounded hover:bg-green-700"
      @click="sendToBackend"
    >
      Обчислити фінальні ваги альтернатив
    </button>

    <div
      v-if="finalResult.length"
      class="mt-6 p-4 bg-gray-50 border rounded-xl"
    >
      <h3 class="text-xl font-bold mb-3">Фінальні ваги альтернатив:</h3>
      <ul class="list-disc list-inside space-y-1">
        <li v-for="(weight, index) in finalResult" :key="index">
          {{ alternatives[index] }}: {{ weight.toFixed(3) }}
        </li>
      </ul>
      <div
        v-if="recommendation"
        class="mt-4 p-4 bg-yellow-50 border-l-4 border-yellow-400 text-gray-800 rounded"
      >
        {{ recommendation }}
      </div>

      <WeightsChart :labels="alternatives" :values="finalResult" />
    </div>
  </div>
</template>

<script>
import WeightsChart from "./WeightsChart.vue";

export default {
  props: {
    criteriaLabels: Array,
    criteriaWeights: Array,
    initialMatrices: Object,
    alternatives: Array,
  },
  components: {
    WeightsChart,
  },
  data() {
    return {
      newAlternative: "",
      comparisons: {},
      matrices: {},
      finalResult: [],
      recommendation: "",
      consistency: {}, // ✅ ДОДАЙ СЮДИ
      scale: {
        1: "Однаково",
        3: "Помірно краща",
        5: "Суттєво краща",
        7: "Сильно краща",
        9: "Абсолютно краща",
        0.333: "Гірша (1/3)",
        0.2: "Помітно гірша (1/5)",
        0.143: "Сильно гірша (1/7)",
        0.111: "Абсолютно гірша (1/9)",
      },
    };
  },
  watch: {
    alternatives: {
      handler() {
        const pairs = this.getPairs(this.alternatives);
        this.criteriaLabels.forEach((c) => {
          if (
            !this.comparisons[c] ||
            this.comparisons[c].length !== pairs.length
          ) {
            this.$set(this.comparisons, c, Array(pairs.length).fill(1));
          }
        });
        this.emitUpdate(); // для altMatrices
      },
      immediate: true,
    },
  },
  created() {
    const pairs = this.getPairs(this.alternatives);
    this.criteriaLabels.forEach((c) => {
      this.$set(
        this.comparisons,
        c,
        this.initialMatrices[c] || Array(pairs.length).fill(1)
      );
    });
  },
  methods: {
    getPairs(items) {
      const pairs = [];
      for (let i = 0; i < items.length; i++) {
        for (let j = i + 1; j < items.length; j++) {
          pairs.push([items[i], items[j]]);
        }
      }
      return pairs;
    },
    emitUpdate() {
      this.$emit("updateMatrices", { ...this.comparisons });
    },
    addAlternative() {
      const trimmed = this.newAlternative.trim();
      if (trimmed && !this.alternatives.includes(trimmed)) {
        const updated = [...this.alternatives, trimmed];
        this.$emit("updateAlternatives", updated);
      }
      this.newAlternative = "";
    },
    removeAlternative(index) {
      const updated = [...this.alternatives];
      updated.splice(index, 1);
      this.$emit("updateAlternatives", updated);
    },
    generateMatrix(criterion) {
      const size = this.alternatives.length;
      const matrix = Array.from({ length: size }, () => Array(size).fill(1));
      const comps = this.comparisons[criterion];
      let k = 0;
      for (let i = 0; i < size; i++) {
        for (let j = i + 1; j < size; j++) {
          const val = comps[k];
          matrix[i][j] = val;
          matrix[j][i] = 1 / val;
          k++;
        }
      }
      this.$set(this.matrices, criterion, matrix);
      this.emitUpdate();
    },
    generateRecommendation() {
      if (!this.finalResult.length) {
        this.recommendation = "";
        return;
      }

      // 1️⃣ Знаходимо кращу і другу альтернативу
      let sorted = this.finalResult
        .map((w, index) => ({ name: this.alternatives[index], weight: w }))
        .sort((a, b) => b.weight - a.weight);

      let best = sorted[0];
      let second = sorted[1] || { weight: 0 };

      let diff = best.weight - second.weight;

      // 2️⃣ Текст рекомендації по вибору
      let text = `Рекомендована альтернатива: ${best.name}. `;

      if (diff > 0.1) {
        text += "Її ваги значно перевищують інші. ";
      } else {
        text += "Різниця з іншими альтернативами незначна. ";
      }

      // 3️⃣ Аналіз узгодженості
      let inconsistent = [];
      for (let crit in this.consistency) {
        if (this.consistency[crit].cr > 0.1) {
          inconsistent.push(`${crit} (CR = ${this.consistency[crit].cr})`);
        }
      }

      if (inconsistent.length === 0) {
        text +=
          "Усі матриці мають прийнятну узгодженість. Результати є достовірними.";
      } else {
        text +=
          "Зверніть увагу: для критерію(їв) " +
          inconsistent.join(", ") +
          " рівень узгодженості слабкий. Результати можуть бути менш надійними.";
      }

      this.recommendation = text;
    },

    sendToBackend() {
      fetch("http://127.0.0.1:5000/final-calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          criteria_weights: this.criteriaWeights,
          alternative_matrices: this.matrices,
        }),
      })
        .then((res) => res.json())
        .then((data) => {
          this.finalResult = data.final_scores;
          this.consistency = data.consistency; // ✅ Зберігаємо CI/CR
          this.generateRecommendation();
        })
        .catch((err) => {
          alert("Помилка при обчисленні фінальних ваг: " + err.message);
        });
    },
  },
};
</script>
