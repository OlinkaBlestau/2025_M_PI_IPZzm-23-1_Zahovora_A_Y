<script>
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale
} from 'chart.js'
import ChartDataLabels from 'chartjs-plugin-datalabels'

ChartJS.register(
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
  ChartDataLabels
)

export default {
  name: 'WeightsChart',
  components: {
    Bar
  },
  props: {
    labels: {
      type: Array,
      required: true
    },
    values: {
      type: Array,
      required: true
    }
  },
  computed: {
    chartData() {
      return {
        labels: this.labels,
        datasets: [
          {
            label: 'Підсумкові ваги альтернатив',
            data: this.values,
            backgroundColor: '#0ea5e9'
          }
        ]
      }
    },
    chartOptions() {
      return {
        responsive: true,
        indexAxis: 'y',
        scales: {
          x: {
            min: 0,
            max: 1,
            ticks: {
              stepSize: 0.1
            }
          }
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: context => `${(context.raw * 100).toFixed(1)}%`
            }
          },
          datalabels: {
            anchor: 'end',
            align: 'right',
formatter: value => {
  return value > 0 ? `${(value * 100).toFixed(1)}%` : '';
},
            color: '#1f2937',
            font: {
              weight: 'bold'
            }
          }
        }
      }
    }
  }
}
</script>

<template>
  <Bar :data="chartData" :options="chartOptions" />
</template>
