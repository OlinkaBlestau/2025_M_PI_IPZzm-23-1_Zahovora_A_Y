<template>
  <div class="max-w-4xl mx-auto mt-10 p-6 bg-white rounded-xl shadow-md">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">
      Крок 1: Порівняння критеріїв
    </h2>

    <!-- Додати критерій -->
    <div class="flex gap-2 mb-4">
      <input
        v-model="newCriterion"
        placeholder="Назва критерію"
        class="border p-2 rounded w-full"
      />
      <button
        @click="addCriterion"
        class="bg-blue-600 text-white px-4 py-2 rounded"
      >
        Додати
      </button>
    </div>

    <!-- Поточні критерії -->
    <div class="mb-6">
      <span
        v-for="(c, index) in criteria"
        :key="index"
        class="inline-block bg-gray-200 text-sm px-3 py-1 rounded mr-2 mb-2"
      >
        {{ c }}
        <button @click="removeCriterion(c)" class="ml-1 text-red-500 font-bold">
          ×
        </button>
      </span>
    </div>

    <!-- Порівняння пар -->
    <div class="space-y-2 mb-4">
      <div v-for="(pair, index) in pairs" :key="index" class="mb-4">
        <label class="block text-sm font-medium text-gray-700 mb-1">
          Наскільки
          <span class="text-indigo-600 font-semibold">{{ pair[0] }}</span>
          важливіше за
          <span class="text-indigo-600 font-semibold">{{ pair[1] }}</span
          >?
        </label>
        <select
          v-model="comparisons[index]"
          class="block w-full px-3 py-2 border rounded shadow-sm"
        >
          <option
            v-for="(label, value) in scale"
            :key="value"
            :value="parseFloat(value)"
          >
            {{ label }}
          </option>
        </select>
      </div>
    </div>
    <!-- Обчислити -->
    <button
      @click="generateMatrix"
      :disabled="!allSelected"
      class="mt-6 mb-8 px-5 py-2 font-semibold rounded-md shadow-sm transition text-white"
      :class="
        !allSelected
          ? 'bg-gray-400 cursor-not-allowed'
          : 'bg-indigo-600 hover:bg-indigo-700'
      "
    >
      Розрахувати матрицю AHP
    </button>

    <!-- Результат -->
    <div v-if="matrix.length" style="mt-6">
      <h3 class="text-lg font-semibold text-gray-800 mb-4">
        Матриця попарного порівняння
      </h3>
      <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-300 text-sm text-center">
          <thead class="bg-gray-100">
            <tr>
              <th class="border px-4 py-2"></th>
              <th v-for="c in criteria" :key="c" class="border px-4 py-2">
                {{ c }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, i) in matrix" :key="i">
              <td class="border px-4 py-2 font-semibold">{{ criteria[i] }}</td>
              <td v-for="(val, j) in row" :key="j" class="border px-4 py-2">
                {{ val.toFixed(3) }}
              </td>
            </tr>
          </tbody>
        </table>
        <div class="mt-4 text-sm">
          <p><strong>CI:</strong> {{ ci }}</p>
          <p><strong>CR:</strong> {{ cr }}</p>
          <p v-if="cr <= 0.1" class="text-green-600 font-semibold">
            Узгодженість прийнятна ✅
          </p>
          <p v-else class="text-red-600 font-semibold">
            Узгодженість слабка ❗ Рекомендується переглянути порівняння.
          </p>
        </div>
      </div>

      <div v-if="weights.length" class="mt-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-2">
          Вектор пріоритетів:
        </h3>
        <ul class="list-disc pl-6 text-gray-700">
          <li v-for="(w, i) in weights" :key="i">
            {{ criteria[i] }}:
            <span class="font-semibold">{{ w.toFixed(3) }}</span>
          </li>
        </ul>
        <div class="mt-4 bg-blue-50 border-l-4 border-blue-400 p-4 rounded">
          <h4 class="text-blue-800 font-semibold mb-2">Висновок:</h4>
          <p class="text-gray-800">
            На основі методу AHP були отримані ваги для кожного критерію.
            Найбільшу вагу має <strong>{{ topCriterion }}</strong> з питомою
            вагою <strong>{{ topWeight.toFixed(3) }}</strong
            >, що свідчить про його домінуюче значення у прийнятті рішення.
          </p>
          <p class="mt-2 text-gray-800">
            Коефіцієнт узгодженості CI: <strong>{{ ci }}</strong
            >, коефіцієнт CR: <strong>{{ cr }}</strong
            >.
            <span v-if="cr <= 0.1" class="text-green-700 font-medium">
              Узгодженість прийнятна — судження є достатньо послідовними.
            </span>
            <span v-else class="text-red-700 font-medium">
              Узгодженість слабка — бажано переглянути деякі порівняння.
            </span>
          </p>
        </div>

        <AhpPriorityChart :weights="ahpCriteriaWeights" />
      </div>
    </div>
  </div>
</template>

<script>
import AhpPriorityChart from "./AhpPriorityChart.vue";

export default {
  components: {
    AhpPriorityChart,
  },
  props: {
    initialCriteria: {
      type: Array,
      default: () => [],
    },
    initialComparisons: {
      type: Array,
      default: () => [],
    },
  },

  data() {
    return {
      newCriterion: "",
      criteria: [],
      comparisons: [],
      matrix: [],
      weights: [],
      ci: null,
      cr: null,
      scale: {
        1: "Однаково важливі",
        3: "Помірно важливі",
        5: "Суттєво важливі",
        7: "Сильно важливі",
        9: "Надзвичайно важливі",
        0.333: "Менш важливі (1/3)",
        0.2: "Значно менш важливі (1/5)",
        0.143: "Сильно менш важливі (1/7)",
        0.111: "Абсолютно менш важливі (1/9)",
      },
    };
  },
  computed: {
    pairs() {
      let result = [];
      for (let i = 0; i < this.criteria.length; i++) {
        for (let j = i + 1; j < this.criteria.length; j++) {
          result.push([this.criteria[i], this.criteria[j]]);
        }
      }
      return result;
    },
    topCriterion() {
      if (!this.weights.length) return "";
      const max = Math.max(...this.weights);
      const index = this.weights.indexOf(max);
      return this.criteria[index];
    },
    topWeight() {
      return Math.max(...this.weights);
    },

    ahpCriteriaWeights() {
      // Створюємо об'єкт {НазваКритерію: Вага}
      return this.criteria.reduce((obj, c, i) => {
        obj[c] = this.weights[i] ?? 0;
        return obj;
      }, {});
    },
    allSelected() {
      // Треба мінімум 2 критерії (тобто хоча б 1 порівняння)
      if (this.criteria.length < 2) return false;

      return (
        this.comparisons.length === this.pairs.length &&
        this.comparisons.every((v) => !!v)
      );
    },
  },
  watch: {
    criteria() {
      this.$emit("updateCriteriaList", this.criteria);
    },
    comparisons: {
      handler() {
        this.$emit("updateComparisons", this.comparisons);
      },
      deep: true,
    },
  },
  mounted() {
    this.criteria = [...this.initialCriteria];
    this.comparisons = [...this.initialComparisons];
  },
  methods: {
    addCriterion() {
      const trimmed = this.newCriterion.trim();
      if (trimmed && !this.criteria.includes(trimmed)) {
        this.criteria.push(trimmed);
        this.comparisons = []; // reset порівняння
      }
      this.newCriterion = "";
    },
    removeCriterion(name) {
      this.criteria = this.criteria.filter((c) => c !== name);
      this.comparisons = [];
    },
    generateMatrix() {
      const size = this.criteria.length;
      const mat = Array.from({ length: size }, () => Array(size).fill(1));
      let pairIndex = 0;
      for (let i = 0; i < size; i++) {
        for (let j = i + 1; j < size; j++) {
          const val = this.comparisons[pairIndex];
          mat[i][j] = val;
          mat[j][i] = 1 / val;
          pairIndex++;
        }
      }
      this.matrix = mat;

      fetch("http://127.0.0.1:5000/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ matrix: mat }),
      })
        .then((res) => res.json()) // перетворити відповідь на JSON
        .then((data) => {
          this.weights = data.weights;
          this.ci = data.ci;
          this.cr = data.cr;
          this.$emit("calculated", this.weights);
        })
        .catch((err) => {
          alert("Помилка при обчисленні ваг: " + err.message);
        });
    },
  },
};
</script>
