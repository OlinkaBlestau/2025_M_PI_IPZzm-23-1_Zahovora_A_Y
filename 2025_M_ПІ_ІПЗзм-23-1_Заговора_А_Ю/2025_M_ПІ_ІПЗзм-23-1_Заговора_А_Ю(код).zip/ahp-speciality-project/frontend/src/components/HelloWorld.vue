<template>
  <div class="p-4">
    <h2>AHP Matrix Input</h2>
    <textarea v-model="matrixInput" rows="6" cols="60" placeholder="Введіть матрицю у форматі JSON"></textarea>
    <br />
    <button @click="calculate" class="mt-2">Обчислити</button>

    <div v-if="result.length" class="mt-4">
      <h3>Результат:</h3>
      <ul>
        <li v-for="(val, index) in result" :key="index">Критерій {{ index + 1 }}: {{ val.toFixed(3) }}</li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      matrixInput: `[
  [1, 3, 0.5],
  [0.333, 1, 0.2],
  [2, 5, 1]
]`,
      result: []
    };
  },
  methods: {
    async calculate() {
      try {
        const response = await fetch("http://127.0.0.1:5000/calculate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ matrix: JSON.parse(this.matrixInput) })
        });
        const data = await response.json();
        this.result = data.weights || [];
      } catch (err) {
        alert("Помилка: " + err.message);
      }
    }
  }
};
</script>

<style>
textarea {
  font-family: monospace;
}
</style>
