<template>
  <Bar :data="chartData" :options="chartOptions" />
</template>

<script>
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale
} from 'chart.js'
import ChartDataLabels from 'chartjs-plugin-datalabels'

ChartJS.register(
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
  ChartDataLabels
)

export default {
  name: 'AhpPriorityChart',
  components: { Bar },
  props: {
    weights: {
      type: Object,
      required: true
    }
  },
  computed: {
    chartData() {
      return {
        labels: Object.keys(this.weights),
        datasets: [
          {
            label: 'AHP: Ваги критеріїв',
            data: Object.values(this.weights),
            backgroundColor: '#0ea5e9' // синій (tailwind blue-500)
          }
        ]
      }
    },
    chartOptions() {
      return {
        responsive: true,
        indexAxis: 'y',
        scales: {
          x: {
            min: 0,
            max: 1,
            ticks: {
              stepSize: 0.1,
              color: '#374151',
              font: {
                size: 12
              }
            },
            grid: {
              color: '#e5e7eb'
            }
          },
          y: {
            ticks: {
              color: '#374151',
              font: {
                size: 13,
                weight: 'bold'
              }
            }
          }
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: context => `${(context.raw * 100).toFixed(1)}%`
            }
          },
          datalabels: {
            anchor: 'center',
            align: 'center',
            formatter: value => {
              return value > 0 ? `${(value * 100).toFixed(1)}%` : '';
            },
            color: '#000',
            font: {
              size: 14,
              weight: 'bold'
            }
          }
        }
      }
    }
  }
}
</script>
