<template>
  <div>
    <h2 class="text-2xl font-bold text-gray-800 mb-6">
      Крок 1: Порівняння критеріїв
    </h2>
    <div class="flex gap-2 mb-4">
      <input
        v-model="newCriterion"
        placeholder="Назва критерію"
        class="border p-2 rounded w-full"
      />
      <button
        @click="addCriterion"
        class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Додати
      </button>
    </div>

    <!-- Список критеріїв як теги -->
    <div class="flex flex-wrap gap-2 mb-6">
      <span
        v-for="(crit, index) in criteria"
        :key="index"
        class="bg-gray-200 text-sm px-3 py-1 rounded flex items-center"
      >
        {{ crit }}
        <button
          @click="removeCriterion(index)"
          class="ml-2 text-red-600 font-bold"
        >
          ×
        </button>
      </span>
    </div>

    <!-- Залежності між критеріями -->
    <div class="mb-8 p-4 bg-white shadow rounded">
      <h3 class="text-lg font-semibold text-gray-800 mb-4">
        Залежності між критеріями
      </h3>
      <div v-for="(crit, index) in criteria" :key="`dep-${index}`" class="mb-4">
        <label class="block font-medium text-gray-700 mb-1"
          >{{ crit }} впливає на:</label
        >
        <div class="flex flex-wrap gap-4 pl-4">
          <label
            v-for="(target, tIndex) in criteria"
            :key="`target-${tIndex}`"
            class="flex items-center gap-2 text-gray-700"
            ><input
              type="checkbox"
              :checked="dependencies[crit]?.includes(target)"
              @change="toggleDependency(crit, target, $event)"
              :disabled="crit === target"
              class="w-4 h-4 text-blue-600 border-gray-300 rounded"
            />
            {{ target }}
          </label>
        </div>
      </div>
    </div>

    <!-- Матриця парних порівнянь -->
    <div class="mb-8 p-4 bg-white shadow rounded">
      <h3 class="text-lg font-semibold text-gray-800 mb-1">
        Матриця парних порівнянь критеріїв
      </h3>
      <p class="text-sm text-gray-500 mb-4">
        Вкажіть, наскільки один критерій важливіший за інший (за шкалою від 1 до
        9).
        <br />
        Наприклад:
        <span class="italic"
          >"Інтереси" важливіші за "Зарплату" у 5 разів → введіть 5</span
        >.
      </p>
      <table class="table-auto w-full border border-gray-300 text-center">
        <thead class="bg-gray-100">
          <tr>
            <th class="p-2 border border-gray-300"></th>
            <th
              v-for="c2 in criteria"
              :key="c2"
              class="p-2 border border-gray-300 font-semibold text-gray-700"
            >
              {{ c2 }}
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(c1, i) in criteria" :key="c1" class="even:bg-gray-50">
            <th
              class="p-2 border border-gray-300 text-left font-medium text-gray-700"
            >
              {{ c1 }}
            </th>
            <td
              v-for="(c2, j) in criteria"
              :key="`cell-${i}-${j}`"
              class="p-2 border border-gray-300"
            >
              <!-- 🔒 Сам на себе — 1 і заблокований -->
              <input
                v-if="i === j"
                type="number"
                :value="1"
                disabled
                class="w-20 px-2 py-1 border border-gray-200 bg-gray-100 text-center text-gray-500 text-sm"
              />

              <!-- ✅ Редаговане значення -->
              <input
                v-else
                type="number"
                min="1"
                max="9"
                step="any"
                class="w-20 px-2 py-1 border border-gray-300 rounded text-center text-sm"
                :value="comparisons[i][j]"
                @input="updateComparison(i, j, $event.target.value)"
              />
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Впливи критеріїв -->
    <div class="mb-8 p-4 bg-white shadow rounded">
      <h3 class="text-lg font-semibold text-gray-800 mb-1">Впливи критеріїв</h3>
      <p class="text-sm text-gray-500 mb-4">
        Вкажіть, наскільки один критерій впливає на інший (0 — немає впливу, до
        9 — сильний вплив).
        <br />
        Наприклад:
        <span class="italic"
          >"Попит" сильно впливає на "Зарплату" → введіть 8</span
        >.
      </p>
      <div v-for="c1 in criteria" :key="`inf-${c1}`" class="mb-4">
        <div
          v-for="c2 in criteria.filter((item) => item !== c1)"
          :key="`inf-${c1}-${c2}`"
          class="flex items-center gap-2 mb-2 text-gray-700"
        >
          <span class="w-44">{{ c1 }} → {{ c2 }}:</span>
          <input
            v-model.number="influence[`${c1},${c2}`]"
            type="number"
            min="0"
            max="9"
            step="any"
            class="w-20 px-2 py-1 border border-gray-300 rounded text-center"
          />
        </div>
      </div>
    </div>

    <button
      @click="calculateAnp"
      :disabled="isAnpDisabled"
      class="mt-2 px-5 py-2 font-semibold rounded-md shadow-sm transition text-white"
      :class="
        !isAnpDisabled
          ? 'bg-indigo-600 hover:bg-indigo-700'
          : 'bg-gray-400 cursor-not-allowed'
      "
    >
      Розрахувати матрицю ANP
    </button>

    <!-- Виведення результатів -->
    <div v-if="result">
      <h3 class="text-lg font-semibold text-gray-800 mb-4 mt-3">
        Суперматриця
      </h3>
      <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-300 text-sm text-center">
          <thead class="bg-gray-100">
            <tr>
              <th class="border px-4 py-2"></th>
              <th class="border px-4 py-2" v-for="c2 in criteria" :key="c2">
                {{ c2 }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(c1, i) in criteria" :key="c1">
              <th class="border px-4 py-2 font-semibold">{{ c1 }}</th>
              <td
                class="border px-4 py-2"
                v-for="(c2, j) in criteria"
                :key="c2"
              >
                {{ result.supermatrix[i][j].toFixed(3) }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <h3 class="text-lg font-semibold text-gray-800 mb-2 mt-4">
        Вектор пріоритетів:
      </h3>
      <ul class="list-disc pl-6 text-gray-700">
        <li v-for="(value, crit) in result.priority_vector" :key="crit">
          {{ crit }}: <span class="font-semibold">{{ value.toFixed(3) }} </span>
        </li>
      </ul>

      <div class="mt-4 bg-blue-50 border-l-4 border-blue-400 p-4 rounded">
        <h4 class="text-blue-800 font-semibold mb-2">Висновок:</h4>
        <p class="text-gray-800">
          На основі методу ANP були отримані ваги для кожного критерію, які
          враховують залежності та взаємний вплив між ними. Найбільший пріоритет
          має <strong>{{ topCriterion }}</strong> з вагою
          <strong>{{ topWeight.toFixed(3) }}</strong
          >.
        </p>

        <p class="mt-2 text-gray-800">
          Зверніть увагу, що на відміну від AHP, у ANP враховуються зв’язки між
          критеріями. Це може призводити до нульових ваг, якщо на деякі критерії
          не спрямовано впливу.
        </p>

        <p
          v-if="zeroWeightCriteria.length"
          class="mt-2 text-red-700 font-medium"
        >
          Наступні критерії мають нульову вагу:
          {{ zeroWeightCriteria.join(", ") }}. Перевірте, чи мають вони вхідні
          залежності.
        </p>
      </div>

      <PriorityChart :data="result.priority_vector" class="mt-8" />
    </div>
  </div>
</template>

<script>
import axios from "axios";
import PriorityChart from "./PriorityChart.vue";

export default {
  props: {
    initialCriteria: {
      type: Array,
      default: () => [],
    },
    initialDependencies: {
      type: Object,
      default: () => ({}),
    },
    initialComparisons: {
      type: Array,
      default: () => [],
    },
    initialInfluence: {
      type: Object,
      default: () => ({}),
    },
  },

  components: {
    PriorityChart,
  },
  data() {
    return {
      newCriterion: "", // 👈 поле для введення назви критерію
      criteria: ["Зарплата", "Інтерес", "Попит"],
      dependencies: {},
      explanation: "",

      comparisons: [
        [1, 1, 1],
        [1, 1, 1],
        [1, 1, 1],
      ],
      influence: {},
      result: null,
    };
  },
  created() {
    if (this.initialCriteria.length) {
      this.criteria = [...this.initialCriteria];
    }

    if (this.initialComparisons.length) {
      this.comparisons = JSON.parse(JSON.stringify(this.initialComparisons));
    }

    if (Object.keys(this.initialDependencies).length) {
      this.dependencies = JSON.parse(JSON.stringify(this.initialDependencies));
    }

    if (Object.keys(this.initialInfluence).length) {
      this.influence = JSON.parse(JSON.stringify(this.initialInfluence));
    }
  },
  computed: {
  topCriterion() {
    if (!this.result || !this.result.priority_vector) return '';
    const entries = Object.entries(this.result.priority_vector);
    const max = Math.max(...entries.map(e => e[1]));
    const item = entries.find(e => e[1] === max);
    return item?.[0] || '';
  },
  topWeight() {
    if (!this.result || !this.result.priority_vector) return 0;
    return Math.max(...Object.values(this.result.priority_vector));
  },
  zeroWeightCriteria() {
    if (!this.result || !this.result.priority_vector) return [];
    return Object.entries(this.result.priority_vector)
  .filter(([, v]) => v === 0)
      .map(([k]) => k);
  },
  isAnpDisabled() {
    const allDependenciesSelected = this.criteria.every(
      (crit) => this.dependencies[crit] && this.dependencies[crit].length > 0
    );

    const matrixFilled =
      this.comparisons.length === this.criteria.length &&
      this.comparisons.every(
        (row, i) =>
          row.length === this.criteria.length &&
          row.every((val, j) => i === j || (val && !isNaN(val) && val > 0))
      );

    const expectedInfluenceCount =
      this.criteria.length * (this.criteria.length - 1);
    const actualInfluenceCount = Object.entries(this.influence || {}).filter(
      ([key, val]) => {
        const [a, b] = key.split(",");
        return a !== b && val !== null && val !== "" && !isNaN(val);
      }
    ).length;

    const allInfluenceFilled = actualInfluenceCount === expectedInfluenceCount;

    return !(allDependenciesSelected && matrixFilled && allInfluenceFilled);
  },
},
  methods: {
    toggleDependency(crit, target, event) {
      if (!this.dependencies[crit]) {
        this.$set(this.dependencies, crit, []);
      }

      if (crit === target) return;

      if (event.target.checked) {
        if (!this.dependencies[crit].includes(target)) {
          this.dependencies[crit].push(target);
        }
      } else {
        this.dependencies[crit] = this.dependencies[crit].filter(
          (dep) => dep !== target
        );
      }
    },
    
    // ✅ новий варіант додавання критерію
    addCriterion() {
      const name = this.newCriterion.trim();
      if (!name || this.criteria.includes(name)) return;

      this.criteria.push(name);
      const size = this.criteria.length;
      this.comparisons.forEach((row) => row.push(1));
      this.comparisons.push(Array(size).fill(1));
      this.newCriterion = "";
      this.$emit("updateCriteria", this.criteria);

    },

    removeCriterion(index) {
      this.criteria.splice(index, 1);
      this.comparisons.splice(index, 1);
      this.comparisons.forEach((row) => row.splice(index, 1));
      this.$emit("updateCriteria", this.criteria);

    },
    updateComparison(i, j, value) {
      const num = parseFloat(value);
      if (!num || num < 1 || num > 9) return;

      this.$set(this.comparisons[i], j, num);
      this.$set(this.comparisons[j], i, parseFloat((1 / num).toFixed(3)));
    },

    async calculateAnp() {
      for (let crit of this.criteria) {
        if (this.dependencies[crit]) {
          this.dependencies[crit] = this.dependencies[crit].filter(
            (dep) => dep !== crit
          );
        }
      }
      this.$emit("updateCriteria", this.criteria);
      this.$emit("updateDependencies", this.dependencies);
      this.$emit("updateComparisons", this.comparisons);
      this.$emit("updateInfluence", this.influence);

      const formattedDependencies = {};
      for (let crit of this.criteria) {
        formattedDependencies[crit] = this.dependencies[crit] || [];
      }

      const formattedInfluence = {};
      for (let key in this.influence) {
        const parts = key.split(",");
        if (parts[0] !== parts[1]) {
          formattedInfluence[[parts[0], parts[1]]] = this.influence[key] || 0;
        }
      }

      const payload = {
        criteria: this.criteria,
        dependencies: formattedDependencies,
        comparisons: this.comparisons,
        influence: formattedInfluence,
      };

      console.log("Відправляємо на бекенд:", payload);

      try {
        const response = await axios.post(
          "http://localhost:5000/api/anp",
          payload
        );
        this.result = JSON.parse(JSON.stringify(response.data));
      //this.generateExplanation(this.result.priority_vector);
        console.log("Оновлений результат ANP:", this.result);
        this.$emit("step1Completed", this.result); // 👈 стандартний варіант
      } catch (error) {
        console.error("Помилка при обчисленні ANP:", error);
        if (error.response) {
          console.error("Відповідь сервера:", error.response.data);
        }
      }
    },
  },
};
</script>
