<script>
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale
} from 'chart.js'

ChartJS.register(Title, Tooltip, Legend, BarElement, CategoryScale, LinearScale)

export default {
  props: {
    data: Object
  },
  computed: {
    chartData() {
      return {
        labels: Object.keys(this.data),
        datasets: [
          {
            label: 'CR (коєфіцієнт узгодженості)',
            data: Object.values(this.data).map(item => item.cr),
            backgroundColor: Object.values(this.data).map(item =>
              item.cr <= 0.1 ? 'rgba(34, 197, 94, 0.7)' : 'rgba(239, 68, 68, 0.7)'
            )
          }
        ]
      }
    },
    chartOptions() {
      return {
        responsive: true,
        indexAxis: 'y',
        scales: {
          x: {
            min: 0,
            max: 1,
            ticks: {
              stepSize: 0.1
            }
          }
        },
        plugins: {
          legend: { display: false }
        }
      }
    }
  },
  components: {
    Bar
  }
}
</script>
